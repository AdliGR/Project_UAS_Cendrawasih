<!DOCTYPE html>
<html lang="en">
@include('layouts.header')

</html>