<meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <link rel="icon" type="image/png" href="/material-dashboard-master/assets/img/favicon.png">

  <title>Sekolah Kristen Cendrawasih</title>

  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.3/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="/brighton-html/css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Lato:400,700|Poppins:400,700|Roboto:400,700&display=swap" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="/brighton-html/css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="/brighton-html/css/responsive.css" rel="stylesheet" />
  <style>
    .navbar-nav .nav-item:hover {
        color: #e6e600; 
        text-decoration: none;
        position: relative;
        transition: color 0.3s ease, border-bottom 0.3s ease;
      }

      .navbar-nav .nav-item:hover a {
        color: #e6e600;
        border-bottom: 2px solid #e6e600;
      }
  </style>